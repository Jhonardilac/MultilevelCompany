package test;

public class TestPersons {

	public static void main(String[] args) {
	}
}
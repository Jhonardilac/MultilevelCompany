package runners;

import controllers.Controller;

public class RunnerHost {

	public static void main(String[] args) {
		new Controller().initApp();
	}
}
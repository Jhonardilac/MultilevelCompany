package models.entities;

public enum Gender {
	
	MALE, FEMALE;
	
}
package models.entities;

public enum PersonType {

	COMPANY, MEMBER;
}
package models.entities;

public enum Status {

	ENABLED, DISABLED;
}

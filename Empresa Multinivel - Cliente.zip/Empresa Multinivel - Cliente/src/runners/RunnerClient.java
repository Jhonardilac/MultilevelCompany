package runners;

import controllers.Controller;

public class RunnerClient {

	public static void main(String[] args) {
		new Controller().initApp();
	}
}
